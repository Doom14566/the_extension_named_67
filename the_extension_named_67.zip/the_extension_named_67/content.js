// content.js

// A flag to ensure the audio only plays once per page load.
let audioPlayed = false;

// The number we are looking for.
const targetNumber = "67";

// The path to the audio file, which is accessible via web_accessible_resources.
const audioPath = chrome.runtime.getURL("audio/trigger.mp3");

/**
 * Checks the entire document body for the target number.
 * @returns {boolean} True if the target number is found, false otherwise.
 */
function checkForTargetNumber() {
    // Get all text content from the body.
    // Using innerText or textContent on the body can be slow and might miss content
    // that is visually present but not in the standard text flow.
    // A more robust way is to walk the DOM tree and check text nodes.
    
    const walker = document.createTreeWalker(
        document.body,
        NodeFilter.SHOW_TEXT, // Only look at text nodes
        null,
        false
    );
    
    let node;
    while (node = walker.nextNode()) {
        // Check if the text content of the node contains the target number.
        // We use a regular expression to find "67" but ensure it's not part of a larger number
        // (e.g., "167" or "670"). This is a simple interpretation.
        // For a more literal "67" anywhere, a simple includes() is enough.
        // Let's use a simple includes() for maximum detection.
        if (node.nodeValue.includes(targetNumber)) {
            // console.log("Found target number '67' in text node:", node.nodeValue);
            return true;
        }
    }
    
    // Fallback for elements that might not be in the standard text flow but are important,
    // like input values or attribute text, though the TreeWalker is usually sufficient.
    // We will stick to the TreeWalker for performance and accuracy on visible text.
    
    return false;
}

/**
 * Plays the audio file.
 */
function playAudio() {
    if (audioPlayed) {
        return;
    }
    
    // Create an Audio object
    const audio = new Audio(audioPath);
    
    // Play the audio
    audio.play()
        .then(() => {
            // console.log("Audio started playing successfully.");
            audioPlayed = true;
        })
        .catch(error => {
            // This can happen if the user hasn't interacted with the page yet,
            // due to browser autoplay policies.
            // console.error("Error playing audio:", error);
            
            // A common workaround is to try playing it again on a user interaction,
            // but for a simple extension, we will rely on the user having interacted
            // with the page before the number appears, or simply accept the limitation.
            // Since the user is requesting a simple extension, we will not implement
            // complex autoplay workarounds unless requested.
        });
}

/**
 * The main function to run the logic.
 */
function runDetection() {
    if (audioPlayed) {
        // Stop checking once the audio has played.
        return;
    }

    if (checkForTargetNumber()) {
        playAudio();
    }
}

// --- Initial Check and Observer Setup ---

// 1. Run an initial check immediately on page load.
runDetection();

// 2. Set up a MutationObserver to watch for changes to the DOM.
// This is crucial for dynamic web pages (e.g., single-page applications)
// where content is loaded after the initial page load.
const observer = new MutationObserver((mutationsList, observer) => {
    // We don't need to iterate through mutationsList for this simple check.
    // Any change is enough to trigger a re-check.
    runDetection();
    
    // If the audio has played, we can disconnect the observer to save resources.
    if (audioPlayed) {
        observer.disconnect();
        // console.log("Observer disconnected after audio played.");
    }
});

// Configuration for the observer:
const config = { 
    childList: true, // Watch for new nodes being added or removed
    subtree: true,   // Watch all descendants of the body
    characterData: true // Watch for changes to the text content of existing nodes
};

// Start observing the document body for configured mutations.
observer.observe(document.body, config);

// Optional: Also check at a regular interval as a fallback, 
// but the MutationObserver is generally more efficient.
// We will rely on the observer and initial check for efficiency.

